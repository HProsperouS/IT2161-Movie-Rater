package com.example.a211283e_basic

data class MovieInfo(var name: String, var desc: String, var language: String, var release: String, var notsuitable: Boolean)