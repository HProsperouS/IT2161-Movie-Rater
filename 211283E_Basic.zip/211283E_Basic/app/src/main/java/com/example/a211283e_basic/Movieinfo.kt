package com.example.a211283e_basic

class Movieinfo {
    var title = "Venom"
    var overview = "When Eddie Brock acquires the powers of a symbiote, he will have to release his alter-ego Venom to save his life"
    var language = "English"
    var date = "03-10-2018"
    var suitable = "Yes"
}